#!/bin/bash
echo "deleting if exists and creating a log file to track the process"
rm -rf /tmp/m1.log
touch /tmp/m1.log

echo "pvn installing java" >> /tmp/m1.log
sudo add-apt-repository ppa:openjdk-r/ppa >> /tmp/m1.log
sudo apt-get update >> /tmp/m1.log
sudo apt-get install -y fontconfig openjdk-17-jre openjdk-17-jdk >> /tmp/m1.log

echo "pvn installing jenkins" >> /tmp/m1.log
sudo wget -O /usr/share/keyrings/jenkins-keyring.asc https://pkg.jenkins.io/debian-stable/jenkins.io-2023.key >> /tmp/m1.log
echo deb [signed-by=/usr/share/keyrings/jenkins-keyring.asc] https://pkg.jenkins.io/debian-stable binary/ | sudo tee /etc/apt/sources.list.d/jenkins.list >> /tmp/m1.log
sudo apt-get update >> /tmp/m1.log
sudo apt-get install jenkins -y >> /tmp/m1.log

echo "installing terraform" >> /tmp/m1.log
sudo wget https://raw.githubusercontent.com/lerndevops/labs/master/scripts/installTerraform.sh -P /tmp >> /tmp/m1.log
sudo chmod 755 /tmp/installTerraform.sh >> /tmp/m1.log
sudo bash /tmp/installTerraform.sh >> /tmp/m1.log
