#!/bin/bash
echo "deleting if exists and creating a log file to track the process"
rm -rf /tmp/m24.log
touch /tmp/m24.log

## Install Docker
echo "pvn installing docker" >> /tmp/m24.log
sudo wget https://raw.githubusercontent.com/lerndevops/labs/master/scripts/installDocker.sh -P /tmp >> /tmp/m24.log
sudo chmod 755 /tmp/installDocker.sh >> /tmp/m24.log
sudo bash /tmp/installDocker.sh >> /tmp/m24.log
sudo systemctl restart docker.service >> /tmp/m24.log

## Install CRI-Docker
echo "pvn installing cri" >> /tmp/m24.log
sudo wget https://raw.githubusercontent.com/lerndevops/labs/master/scripts/installCRIDockerd.sh -P /tmp >> /tmp/m24.log
sudo chmod 755 /tmp/installCRIDockerd.sh >> /tmp/m24.log
sudo bash /tmp/installCRIDockerd.sh >> /tmp/m24.log
sudo systemctl restart cri-docker.service >> /tmp/m24.log

## Install kubeadm,kubelet,kubectl
echo "pvn installing docker" >> /tmp/m24.log
sudo wget https://raw.githubusercontent.com/lerndevops/labs/master/scripts/installK8S.sh -P /tmp >> /tmp/m24.log
sudo chmod 755 /tmp/installK8S.sh >> /tmp/m24.log
sudo bash /tmp/installK8S.sh >> /tmp/m24.log
