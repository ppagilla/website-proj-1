#!/bin/bash
echo "deleting if exists and creating a log file to track the process"
rm -rf /tmp/m3.log
touch /tmp/m3.log

echo "pvn installing java" >> /tmp/m3.log
sudo add-apt-repository ppa:openjdk-r/ppa -y >> /tmp/m3.log
sudo apt-get update >> /tmp/m3.log
sudo apt-get install -y fontconfig openjdk-17-jre openjdk-17-jdk >> /tmp/m3.log

## Install Docker
echo "pvn installing docker" >> /tmp/m3.log
sudo wget https://raw.githubusercontent.com/lerndevops/labs/master/scripts/installDocker.sh -P /tmp >> /tmp/m3.log
sudo chmod 755 /tmp/installDocker.sh >> /tmp/m3.log
sudo bash /tmp/installDocker.sh >> /tmp/m3.log
sudo systemctl restart docker.service >> /tmp/m3.log

## Install CRI-Docker
echo "pvn installing cri" >> /tmp/m3.log
sudo wget https://raw.githubusercontent.com/lerndevops/labs/master/scripts/installCRIDockerd.sh -P /tmp >> /tmp/m3.log
sudo chmod 755 /tmp/installCRIDockerd.sh >> /tmp/m3.log
sudo bash /tmp/installCRIDockerd.sh >> /tmp/m3.log
sudo systemctl restart cri-docker.service >> /tmp/m3.log

## Install kubeadm,kubelet,kubectl
echo "pvn installing k8s related" >> /tmp/m3.log
sudo wget https://raw.githubusercontent.com/lerndevops/labs/master/scripts/installK8S.sh -P /tmp >> /tmp/m3.log
sudo chmod 755 /tmp/installK8S.sh >> /tmp/m3.log
sudo bash /tmp/installK8S.sh >> /tmp/m3.log
